/*
 *  globalConst.h
 *  HMMBrain
 *
 *  Created by Arend on 9/16/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _globalConst_h_included_
#define _globalConst_h_included_

#define maxNodes 16
#define definedCue 0



#endif