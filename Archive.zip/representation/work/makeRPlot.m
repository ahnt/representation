function [O] = makeRPlot( data )
    O=0;
    k=1;
    for i=0:3
        for j=0:9
            subplot(4,10,k),plot(1:64:10000,data(:,2+(i*10)+j));
            axis([0 10000 0.0 0.5]);
            k=k+1;
        end
    end
end

