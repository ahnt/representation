function [O] = makeKOPlot( data )
    O=0;
    k=1;
    for i=4:13
        for j=0:1
            subplot(10,2,k),bar(data(:,1),(data(:,3+(i*2)+j)-data(:,2))/80);
            axis([0 10000 -1.0 0.1]);
            if(j==0)
                ylabel(num2str(i));
            end
            k=k+1;
        end
    end
end

