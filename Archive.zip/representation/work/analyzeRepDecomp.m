function [R,data] = analyzeRepDecomp(filename)
    data=load('representationalDecompositionData.txt');
    k=1;
    for i=1:15
        Ni=find(data(:,1)==i);
        D=data(Ni,:);
        Mi=find(D(:,19)==max(D(:,19)));
        DD=D(Mi,:);
        MiM=find(DD(:,18)==min(DD(:,18)));
        for j=1:length(MiM)
            R(k,1)=i;
            R(k,2)=DD(MiM(j),19);
            R(k,3:12)=DD(MiM(j),7:16);
            k=k+1;
            sprintf('%d %f %s\n',i,DD(MiM(j),19),num2str(DD(MiM(j),7:16)))
        end
        %sprintf('%d %f\n',i,DD(MiM(1),19))
    end
end

