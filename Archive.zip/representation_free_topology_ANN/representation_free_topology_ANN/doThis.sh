#!/bin/sh -login
#PBS -l nodes=1:ppn=1,walltime=12:00:00,mem=2gb
#PBS -j oe
cd representationANN
for recLev in 0 1 2 3 4; do
	./representationANN resultFile_ANN_"$recLev"_$localN.txt LOD_ANN_"$recLev"_$localN.txt genome_ANN_"$recLev"_$localN.txt $recLev
done