for N in 0 1 2 3 4 5 6 7 8 9; do
	for M in 0 1 2 3 4 5 6 7 8 9; do
#for N in 0; do
#	for M in 0; do
		qsub -v localN="0$M$N" doThis.sh
		qsub -v localN="1$M$N" doThis.sh
	done
done